# NAYABÉ website ko online (live) kaise karein

Aap ka link tab banega jab website kisi hosting server par chalegi. Neeche step by step tareeqa hai.
(Maine aap ki taraf se ye nahi kiya, kyunke hosting aap ke apne account par honi chahiye.)

## 1) Computer par test (optional)
1. nodejs.org se Node.js (LTS) install karein.
2. Is folder mein terminal kholein:
   `npm install`
   `ADMIN_KEY=apna-password npm start`   (Windows PowerShell: `$env:ADMIN_KEY="apna-password"; npm start`)
3. Browser: http://localhost:3000   |   Admin: http://localhost:3000/admin.html

## 2) GitHub par upload
1. github.com par free account banayein, **New repository** (Private chunein).
2. Is folder ki saari files upload karein (`node_modules` na daalein). `.gitignore` file customer data ko upload hone se rokti hai.

## 3) Render.com par deploy (link yahin se milega)
1. render.com par account banayein, **New > Web Service**, apna GitHub repo chunein.
2. Build Command: `npm install`   |   Start Command: `npm start`
3. **Environment variables** mein ye daalein:
   - `ADMIN_KEY` = apna strong password (admin panel ke liye) **zaroori**
   - `SITE_URL` = aap ka final link, jaise `https://nayabe.onrender.com` (ya apna domain)
   - `SMTP_USER` = officialnayabe@gmail.com aur `SMTP_PASS` = Gmail App Password  (har naye order ki email aap ko milegi) **bohat zaroori**
   - `DATA_DIR` = `/var/data`  (neeche "Orders ka data" dekhein)
   - `STRIPE_SECRET_KEY` = sirf tab jab card payment ka gateway account ho (neeche dekhein)
4. **Create Web Service** dabayein. Kuch minutes baad Render aap ko link dega, jaise `https://nayabe.onrender.com`. **Wohi aap ki website ka link hai.**

### Orders ka data (bohat zaroori)
Website orders, customers aur messages `data/` folder ki files mein save karti hai. Render ke **free plan** par ye files restart/redeploy par **mit jati hain**, aur free site kuch der idle rehne par so jati hai (pehla page der se khulta hai).
Asli store ke liye:
- Paid plan lein, **Disks** mein ek persistent disk banayein, Mount Path `/var/data`, aur `DATA_DIR=/var/data` set karein. (Plans aur qeematein badalti rehti hain, render.com/pricing par dekh lein.)
- Aur SMTP email zaroor lagayein, taake har order ki copy aap ki email mein bhi rahe.
Dusre options: Railway.app, ya Hostinger / DigitalOcean VPS (Node.js chalane wala).

## 4) Apna domain (jaise nayabe.pk ya nayabe.com)
1. Domain kisi registrar se kharidein (Namecheap, GoDaddy, ya .pk ke liye PKNIC se).
2. Render > aap ki service > **Settings > Custom Domains** mein domain add karein.
3. Render jo DNS records dikhaye wo registrar ke DNS page mein daal dein. HTTPS (https://) Render khud laga deta hai.
4. `SITE_URL` ko apne domain par badal dein.

## 5) Card payment kaise chalega
Website mein card payment ka poora system bana hua hai (checkout par "Credit / debit card" option, payment ke baad order khud "paid" ho jata hai). Wo tab dikhta hai jab `STRIPE_SECRET_KEY` set ho.
- Card payment lene ke liye payment gateway ka **merchant account** chahiye. Stripe Pakistan ke businesses ko accounts nahi deta (stripe.com/global par check kar lein). Pakistan mein aam taur par Safepay, PayFast, Paymob, JazzCash aur Easypaisa ke merchant accounts use hote hain. Dekh lein kaun sa aap ke business ko approve karta hai.
- Gateway mil jaye to uska API documentation mujhe bhej dein, main code us ke hisaab se laga dunga.
- **Secret keys kabhi chat ya email mein na bhejein.** Sirf Render ke Environment variables mein daalein.
- Jab tak gateway nahi hai, "Bank transfer / JazzCash / Easypaisa" option istemal karein: Admin > **Payments** mein apna account title, IBAN aur JazzCash/Easypaisa number daalein. Customer ko order ke baad ye details dikhti hain aur wo WhatsApp par screenshot bhejta hai. Aap Admin > Orders mein payment status "paid" kar sakte hain.

## 6) Rozana istemal
- Admin: `https://aap-ka-link/admin.html` (ADMIN_KEY dalein)
- Orders dekhna aur status badalna, promo codes banana, products ki price aur pictures badalna, **New** tick karna.
- Data ka backup: `data/orders.json`, `users.json`, `messages.json` ki copy time to time download kar lein.
