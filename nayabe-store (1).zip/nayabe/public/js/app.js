/* NAYABÉ shared script: header, footer, cart, account, promo, helpers */
const WA_NUMBER = '923021606608';
const STORE_EMAIL = 'officialnayabe@gmail.com';
const FREE_OVER = 3000, SHIP_FEE = 200;

const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const money = (n) => 'Rs ' + Number(n).toLocaleString('en-PK');
const ICON = (d) => `<svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
const I = {
  bag: ICON('<path d="M6 8h12l-1 12H7L6 8z"/><path d="M9 8V6a3 3 0 0 1 6 0v2"/>'),
  user: ICON('<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7"/>'),
  search: ICON('<circle cx="11" cy="11" r="7"/><path d="M20 20l-3.5-3.5"/>'),
};

const MARK = '<svg viewBox="0 0 64 64" aria-hidden="true"><rect x="2.5" y="2.5" width="59" height="59" rx="11" fill="#14100D" stroke="#B8925A" stroke-width="2"/><rect x="5.5" y="5.5" width="53" height="53" rx="8.5" fill="none" stroke="#B8925A" stroke-width=".7" opacity=".7"/><g fill="#F5EEE2"><rect x="14" y="17" width="13" height="2.2"/><rect x="35" y="17" width="15" height="2.2"/><rect x="19.6" y="19" width="3.2" height="26"/><rect x="41.2" y="19" width="3.2" height="26"/><polygon points="20,18 28,18 44.6,45.5 36.6,45.5"/><rect x="14" y="44.8" width="13" height="2.2"/><rect x="34" y="44.8" width="12" height="2.2"/></g></svg>';
const LOGO = `${MARK}<span>NAYABÉ</span>`;

/* ---------- API + account ---------- */
const Auth = {
  token: () => localStorage.getItem('nayabe_token') || '',
  user() { try { return JSON.parse(localStorage.getItem('nayabe_user')); } catch { return null; } },
  set(t, u) { localStorage.setItem('nayabe_token', t); localStorage.setItem('nayabe_user', JSON.stringify(u)); },
  clear() { localStorage.removeItem('nayabe_token'); localStorage.removeItem('nayabe_user'); },
};
async function api(url, opts = {}) {
  opts.headers = { ...(opts.headers || {}) };
  if (Auth.token()) opts.headers.Authorization = 'Bearer ' + Auth.token();
  const r = await fetch(url, opts);
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
  return data;
}
const post = (url, body) => api(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });

/* ---------- Cart + promo (saved in the browser) ---------- */
const Cart = {
  get() { try { return JSON.parse(localStorage.getItem('nayabe_cart')) || []; } catch { return []; } },
  set(c) { localStorage.setItem('nayabe_cart', JSON.stringify(c)); Cart.badge(); },
  add(id, color, qty = 1) {
    const c = Cart.get(), l = c.find((x) => x.id === id && x.color === color);
    if (l) l.qty = Math.min(l.qty + qty, 20); else c.push({ id, color, qty });
    Cart.set(c);
  },
  setQty(id, color, qty) { Cart.set(Cart.get().map((x) => (x.id === id && x.color === color ? { ...x, qty: Math.max(1, Math.min(20, qty)) } : x))); },
  remove(id, color) { Cart.set(Cart.get().filter((x) => !(x.id === id && x.color === color))); },
  clear() { Cart.set([]); },
  count() { return Cart.get().reduce((n, x) => n + x.qty, 0); },
  badge() { $$('.cart-count').forEach((b) => { const n = Cart.count(); b.textContent = n; b.hidden = !n; }); },
};
const Promo = {
  get() { try { return JSON.parse(localStorage.getItem('nayabe_promo')); } catch { return null; } },
  set(p) { localStorage.setItem('nayabe_promo', JSON.stringify(p)); },
  clear() { localStorage.removeItem('nayabe_promo'); },
};
async function applyPromo(code) {
  const r = await post('/api/promo/validate', { code: String(code).trim() });
  Promo.set({ code: r.code, percent: r.percent }); return r;
}

/* ---------- Product visuals ---------- */
function shade(hex, amt) {
  const n = parseInt(hex.slice(1), 16), f = (v) => Math.max(0, Math.min(255, v + amt));
  return '#' + [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => f(v).toString(16).padStart(2, '0')).join('');
}
function walletSVG(hex = '#1c1c1c') {
  return `<svg viewBox="0 0 200 150" role="img" aria-label="Wallet"><rect x="12" y="22" width="176" height="112" rx="14" fill="${hex}"/><path d="M12 52 Q100 78 188 52 L188 120 Q188 134 174 134 L26 134 Q12 134 12 120Z" fill="${shade(hex, 22)}"/><rect x="150" y="62" width="30" height="22" rx="5" fill="${shade(hex, -28)}"/><circle cx="165" cy="73" r="3.5" fill="#B8893B"/></svg>`;
}
function pic(p, i = 0, colorHex) {
  const img = (p.images || [])[i];
  return img ? `<img src="${esc(img)}" alt="${esc(p.name)}" loading="lazy">` : walletSVG(colorHex || p.colors?.[0]?.hex);
}
function productCard(p) {
  const dots = (p.colors || []).map((c) => `<span class="dot" title="${esc(c.name)}" style="background:${esc(c.hex)}"></span>`).join('');
  const label = p.isNew ? '<span class="tag new">New</span>' : `<span class="tag">${p.category === 'men' ? "Men's" : "Women's"}</span>`;
  const href = '/product.html?id=' + encodeURIComponent(p.id);
  return `<div class="card">
    <a class="pic-link" href="${href}" aria-label="${esc(p.name)}"><div class="pic">${label}${pic(p)}${(p.images || [])[1] ? `<img class="alt" src="${esc(p.images[1])}" alt="" loading="lazy">` : ''}</div></a>
    <h3><a href="${href}">${esc(p.name)}</a></h3>
    <div class="row"><span class="price">${money(p.price)}</span><span class="dots">${dots}</span></div>
    <button class="qa" data-qa="${esc(p.id)}" data-color="${esc(p.colors[0].name)}">${I.bag} Add to cart</button></div>`;
}
document.addEventListener('click', (e) => {
  const b = e.target.closest('[data-qa]'); if (!b) return;
  Cart.add(b.dataset.qa, b.dataset.color, 1); toast('Added to your cart');
  const old = b.innerHTML; b.classList.add('added'); b.textContent = 'Added';
  setTimeout(() => { b.classList.remove('added'); b.innerHTML = old; }, 1200);
});

/* ---------- Header / footer / WhatsApp ---------- */
const TICK = `<span>Free delivery on orders over ${money(FREE_OVER)}</span><span>Use promo code <b>30012008</b> for 10% off</span><span>Cash on delivery across Pakistan</span><span>Order on WhatsApp 0302 1606608</span>`;
function layout() {
  const path = location.pathname, u = Auth.user();
  const on = (h) => (path === h ? 'on' : '');
  $('#site-header').outerHTML = `
  <div class="ticker" role="region" aria-label="Offers"><div class="ticker-track">${[0, 1].map((k) => `<div class="half${k ? ' dup' : ''}"${k ? ' aria-hidden="true"' : ''}>${[0, 1].map(() => TICK).join('')}</div>`).join('')}</div></div>
  <header class="site"><div class="wrap nav">
    <a class="logo" href="/" aria-label="NAYABÉ home">${LOGO}</a>
    <nav class="menu" id="menu" aria-label="Main">
      <a href="/new-arrivals.html" class="${on('/new-arrivals.html')}">New arrivals</a>
      <a href="/shop.html?cat=men">Men</a>
      <a href="/shop.html?cat=women">Women</a>
      <a href="/shop.html" class="${on('/shop.html')}">Shop all</a>
      <a href="/about.html" class="${on('/about.html')}">About us</a>
      <a href="/contact.html" class="${on('/contact.html')}">Contact</a>
    </nav>
    <div class="nav-right">
      <button class="icon-btn" id="sbtn" aria-label="Search" aria-expanded="false">${I.search}</button>
      <a class="icon-btn acct" href="/account.html" aria-label="${u ? 'My account' : 'Login'}">${I.user}<span class="lbl">${u ? esc(u.name.split(' ')[0]) : 'Login'}</span></a>
      <a class="icon-btn" href="/cart.html" aria-label="Cart">${I.bag}<span class="badge cart-count" hidden>0</span></a>
      <button class="burger" id="burger" aria-label="Open menu" aria-expanded="false">Menu</button>
    </div></div>
    <form class="searchbar" id="sbar" action="/shop.html" role="search" hidden><div class="wrap"><input type="search" name="q" placeholder="Search wallets, e.g. bifold, croc, navy" aria-label="Search wallets"></div></form>
  </header>`;
  $('#site-footer').outerHTML = `
  <footer class="site"><div class="wrap">
    <div class="fgrid">
      <div><div class="logo">${LOGO}</div><p class="footer-tag">Wallets for everyday life, for men and women. Order online, pay on delivery.</p></div>
      <div><h4>Shop</h4><a href="/new-arrivals.html">New arrivals</a><a href="/shop.html?cat=men">Men</a><a href="/shop.html?cat=women">Women</a><a href="/shop.html">All wallets</a></div>
      <div><h4>Help</h4><a href="/faq.html">FAQ</a><a href="/shipping.html">Shipping &amp; returns</a><a href="/contact.html">Contact us</a><a href="/account.html">My account</a></div>
      <div><h4>Company</h4><a href="/about.html">About us</a><a href="/privacy.html">Privacy policy</a><a href="mailto:${STORE_EMAIL}">${STORE_EMAIL}</a><a href="https://wa.me/${WA_NUMBER}" target="_blank" rel="noopener">WhatsApp: 0302 1606608</a></div>
    </div>
    <div class="copy"><span>&copy; ${new Date().getFullYear()} NAYABÉ. All rights reserved.</span><span>Cash on delivery available</span></div>
  </div></footer>
  <a class="wa-float" href="https://wa.me/${WA_NUMBER}?text=${encodeURIComponent('Hello NAYABÉ, I have a question about your wallets.')}" target="_blank" rel="noopener" aria-label="Chat on WhatsApp">
    <svg width="30" height="30" viewBox="0 0 32 32" fill="#fff"><path d="M16 3C9 3 3.3 8.6 3.3 15.5c0 2.4.7 4.7 1.9 6.6L3 29l7.100-2.100c1.800 1 3.800 1.500 5.900 1.500 7 0 12.700-5.600 12.700-12.500S23 3 16 3zm0 22.800c-1.900 0-3.700-.5-5.300-1.500l-.4-.2-4.200 1.200 1.300-4-.3-.4a10 10 0 0 1-1.600-5.400C5.500 10 10.200 5.500 16 5.500S26.500 10 26.500 15.500 21.800 25.800 16 25.800zm5.800-7.600c-.3-.2-1.900-.9-2.200-1-.3-.1-.5-.2-.7.200-.2.300-.8 1-1 1.200-.2.200-.4.200-.7.100-.3-.2-1.400-.5-2.600-1.600-1-.9-1.600-1.900-1.800-2.200-.2-.3 0-.5.100-.6l.5-.5c.1-.2.200-.3.300-.5.100-.2.100-.4 0-.5l-1-2.300c-.2-.6-.5-.5-.7-.5h-.6c-.2 0-.5.100-.8.400-.3.300-1.100 1.100-1.100 2.600s1.100 3 1.300 3.200c.2.200 2.200 3.400 5.400 4.700.8.300 1.400.5 1.800.6.800.2 1.500.2 2 .1.600-.1 1.900-.8 2.100-1.500.3-.7.300-1.400.2-1.500-.1-.2-.3-.3-.6-.4z"/></svg>
  </a><div class="toast" id="toast" role="status"></div>`;
  $('#burger').onclick = () => { const o = $('#menu').classList.toggle('open'); $('#burger').setAttribute('aria-expanded', o); };
  $('#sbtn').onclick = () => { const b = $('#sbar'); b.hidden = !b.hidden; $('#sbtn').setAttribute('aria-expanded', !b.hidden); if (!b.hidden) $('#sbar input').focus(); };
  Cart.badge();
}
function toast(msg) {
  const t = $('#toast'); t.textContent = msg; t.classList.add('show');
  clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2200);
}
async function cartDetails() {
  const all = await api('/api/products');
  const lines = Cart.get().map((l) => ({ ...l, p: all.find((p) => p.id === l.id) })).filter((l) => l.p);
  const subtotal = lines.reduce((s, l) => s + l.p.price * l.qty, 0);
  const promo = Promo.get();
  const discount = promo && lines.length ? Math.round(subtotal * promo.percent / 100) : 0;
  const shipping = !lines.length || subtotal >= FREE_OVER ? 0 : SHIP_FEE;
  return { lines, subtotal, promo: discount ? promo : null, discount, shipping, total: subtotal - discount + shipping };
}
const heading = (crumb, title, sub = '') => `<div class="pagehero"><div class="wrap"><div class="crumbs"><a href="/">Home</a> / ${crumb}</div><h1>${title}</h1>${sub ? `<p>${sub}</p>` : ''}</div></div>`;
document.documentElement.classList.add('js');
document.addEventListener('DOMContentLoaded', () => {
  layout();
  const h = $('header.site'); const sc = () => h.classList.toggle('scrolled', scrollY > 8); sc(); addEventListener('scroll', sc, { passive: true });
  const els = $$('section.block, .pagehero + .wrap');
  if (!('IntersectionObserver' in window) || matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  const io = new IntersectionObserver((en) => en.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: 0.08 });
  els.forEach((el, i) => { if (i === 0 && el.getBoundingClientRect().top < innerHeight) return; el.classList.add('reveal'); io.observe(el); });
});
