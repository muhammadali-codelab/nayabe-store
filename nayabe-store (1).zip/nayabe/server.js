const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const app = express();
const PORT = process.env.PORT || 3000;
const ADMIN_KEY = process.env.ADMIN_KEY || 'change-me';
const STORE_EMAIL = 'officialnayabe@gmail.com';
const WHATSAPP = '923021606608';
const FREE_SHIPPING_OVER = 3000;
const SHIPPING_FEE = 200;

const SEED = path.join(__dirname, 'data');
const DATA = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : SEED;
fs.mkdirSync(DATA, { recursive: true });
if (DATA !== SEED) for (const f of ['products.json', 'promos.json']) if (!fs.existsSync(path.join(DATA, f)) && fs.existsSync(path.join(SEED, f))) fs.copyFileSync(path.join(SEED, f), path.join(DATA, f));
const SITE_URL = (process.env.SITE_URL || '').replace(/\/$/, '');
const STRIPE_KEY = process.env.STRIPE_SECRET_KEY || '';
const STRIPE_BASE = process.env.STRIPE_API_BASE || 'https://api.stripe.com';
const files = {
  products: path.join(DATA, 'products.json'),
  orders: path.join(DATA, 'orders.json'),
  messages: path.join(DATA, 'messages.json'),
  users: path.join(DATA, 'users.json'),
  promos: path.join(DATA, 'promos.json'),
  payment: path.join(DATA, 'payment.json'),
};
const defaults = { orders: [], messages: [], users: [], promos: [{ code: '30012008', percent: 10, active: true, used: 0 }], payment: { accountTitle: '', bankName: '', iban: '', jazzcash: '', easypaisa: '', note: '' } };
for (const k of Object.keys(defaults)) if (!fs.existsSync(files[k])) fs.writeFileSync(files[k], JSON.stringify(defaults[k], null, 2));

const read = (f) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return []; } };
const write = (f, d) => fs.writeFileSync(f, JSON.stringify(d, null, 2));
const clean = (s, max = 300) => String(s || '').replace(/[<>]/g, '').trim().slice(0, max);

// ---------- secret + auth helpers ----------
const SECRET_FILE = path.join(DATA, '.secret');
if (!fs.existsSync(SECRET_FILE)) fs.writeFileSync(SECRET_FILE, crypto.randomBytes(32).toString('hex'));
const SECRET = fs.readFileSync(SECRET_FILE, 'utf8');
const sign = (uid) => {
  const p = Buffer.from(JSON.stringify({ u: uid, e: Date.now() + 30 * 864e5 })).toString('base64url');
  return p + '.' + crypto.createHmac('sha256', SECRET).update(p).digest('base64url');
};
const verify = (t) => {
  const [p, s] = String(t || '').split('.');
  if (!p || !s) return null;
  const good = crypto.createHmac('sha256', SECRET).update(p).digest('base64url');
  if (s.length !== good.length || !crypto.timingSafeEqual(Buffer.from(s), Buffer.from(good))) return null;
  try { const d = JSON.parse(Buffer.from(p, 'base64url').toString()); return d.e > Date.now() ? d.u : null; } catch { return null; }
};
const hashPw = (pw, salt = crypto.randomBytes(16).toString('hex')) => ({ salt, hash: crypto.scryptSync(pw, salt, 64).toString('hex') });
const authUser = (req) => {
  const uid = verify((req.get('authorization') || '').replace(/^Bearer /, ''));
  return uid ? read(files.users).find((u) => u.id === uid) || null : null;
};
const publicUser = (u) => ({ id: u.id, name: u.name, email: u.email, phone: u.phone || '', city: u.city || '', address: u.address || '' });

// ---------- optional email ----------
let transporter = null;
if (process.env.SMTP_USER && process.env.SMTP_PASS) {
  try {
    transporter = require('nodemailer').createTransport({ service: 'gmail', auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } });
  } catch (e) { console.log('nodemailer not available'); }
}
const notify = (subject, text) => {
  if (!transporter) return;
  transporter.sendMail({ from: process.env.SMTP_USER, to: STORE_EMAIL, subject, text }).catch((e) => console.log('Email failed:', e.message));
};

// ---------- tiny rate limiter ----------
const hits = new Map();
const limit = (max) => (req, res, next) => {
  const k = req.ip + req.path, now = Date.now();
  const arr = (hits.get(k) || []).filter((t) => now - t < 60000);
  if (arr.length >= max) return res.status(429).json({ error: 'Too many requests. Please wait a minute.' });
  arr.push(now); hits.set(k, arr); next();
};

app.set('trust proxy', 1);
app.use((req, res, next) => {
  res.set({ 'X-Content-Type-Options': 'nosniff', 'X-Frame-Options': 'SAMEORIGIN', 'Referrer-Policy': 'strict-origin-when-cross-origin' });
  next();
});
app.use(express.json({ limit: '100kb' }));
app.use(express.static(path.join(__dirname, 'public')));

// ---------- public API ----------
app.get('/api/products', (req, res) => res.json(read(files.products).filter((p) => p.active !== false)));
app.get('/api/products/:id', (req, res) => {
  const p = read(files.products).find((x) => x.id === req.params.id && x.active !== false);
  return p ? res.json(p) : res.status(404).json({ error: 'Product not found' });
});
const payInfo = () => { const p = Array.isArray(read(files.payment)) ? {} : read(files.payment); return { accountTitle: p.accountTitle || '', bankName: p.bankName || '', iban: p.iban || '', jazzcash: p.jazzcash || '', easypaisa: p.easypaisa || '', note: p.note || '' }; };
const transferOn = () => { const p = payInfo(); return !!(p.iban || p.jazzcash || p.easypaisa); };
app.get('/api/config', (req, res) => res.json({
  whatsapp: WHATSAPP, email: STORE_EMAIL, freeShippingOver: FREE_SHIPPING_OVER, shippingFee: SHIPPING_FEE,
  payments: { cod: true, card: !!STRIPE_KEY, transfer: transferOn() }, transfer: transferOn() ? payInfo() : null,
}));

// promo
const findPromo = (code) => read(files.promos).find((p) => p.active !== false && p.code === String(code || '').trim());
app.post('/api/promo/validate', limit(20), (req, res) => {
  const p = findPromo(req.body?.code);
  if (!p) return res.status(400).json({ error: 'This promo code is not valid.' });
  res.json({ ok: true, code: p.code, percent: p.percent });
});

// accounts
app.post('/api/auth/register', limit(10), (req, res) => {
  const name = clean(req.body?.name, 80), email = clean(req.body?.email, 100).toLowerCase();
  const phone = clean(req.body?.phone, 20), pw = String(req.body?.password || '');
  if (!name || !email || !pw) return res.status(400).json({ error: 'Please fill name, email and password.' });
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return res.status(400).json({ error: 'Please enter a valid email.' });
  if (pw.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters.' });
  const users = read(files.users);
  if (users.some((u) => u.email === email)) return res.status(400).json({ error: 'An account with this email already exists. Please log in.' });
  const user = { id: 'u' + Date.now().toString(36) + crypto.randomBytes(3).toString('hex'), name, email, phone, ...hashPw(pw), createdAt: new Date().toISOString() };
  users.push(user); write(files.users, users);
  res.json({ ok: true, token: sign(user.id), user: publicUser(user) });
});
app.post('/api/auth/login', limit(10), (req, res) => {
  const email = clean(req.body?.email, 100).toLowerCase(), pw = String(req.body?.password || '');
  const u = read(files.users).find((x) => x.email === email);
  const bad = () => res.status(400).json({ error: 'Email or password is not correct.' });
  if (!u) return bad();
  const { hash } = hashPw(pw, u.salt);
  if (hash.length !== u.hash.length || !crypto.timingSafeEqual(Buffer.from(hash), Buffer.from(u.hash))) return bad();
  res.json({ ok: true, token: sign(u.id), user: publicUser(u) });
});
app.get('/api/auth/me', (req, res) => { const u = authUser(req); u ? res.json(publicUser(u)) : res.status(401).json({ error: 'Please log in.' }); });
app.patch('/api/auth/me', (req, res) => {
  const me = authUser(req); if (!me) return res.status(401).json({ error: 'Please log in.' });
  const users = read(files.users), u = users.find((x) => x.id === me.id);
  for (const [k, max] of [['name', 80], ['phone', 20], ['city', 60], ['address', 300]]) if (req.body?.[k] != null) u[k] = clean(req.body[k], max);
  write(files.users, users); res.json(publicUser(u));
});
app.get('/api/my/orders', (req, res) => {
  const u = authUser(req); if (!u) return res.status(401).json({ error: 'Please log in.' });
  res.json(read(files.orders).filter((o) => o.userId === u.id).reverse());
});

// orders
const stripeSession = async (order, base) => {
  const p = new URLSearchParams();
  p.append('mode', 'payment');
  p.append('success_url', `${base}/order-success.html?order=${order.id}&session_id={CHECKOUT_SESSION_ID}`);
  p.append('cancel_url', `${base}/cart.html?payment=cancelled`);
  p.append('client_reference_id', order.id);
  p.append('metadata[orderId]', order.id);
  p.append('line_items[0][quantity]', '1');
  p.append('line_items[0][price_data][currency]', 'pkr');
  p.append('line_items[0][price_data][unit_amount]', String(order.total * 100));
  p.append('line_items[0][price_data][product_data][name]', 'NAYABÉ order ' + order.id);
  p.append('line_items[0][price_data][product_data][description]', order.items.map((l) => `${l.qty} x ${l.name} (${l.color})`).join(', ').slice(0, 400));
  const r = await fetch(STRIPE_BASE + '/v1/checkout/sessions', { method: 'POST', headers: { Authorization: 'Bearer ' + STRIPE_KEY, 'Content-Type': 'application/x-www-form-urlencoded' }, body: p });
  const d = await r.json().catch(() => ({}));
  if (!r.ok || !d.url) throw new Error((d.error && d.error.message) || 'Card payment could not be started.');
  return d;
};

app.post('/api/orders', limit(10), async (req, res) => {
  try {
    const { items, customer, promoCode } = req.body || {};
    const method = ['cod', 'card', 'transfer'].includes(req.body?.payment) ? req.body.payment : 'cod';
    if (method === 'card' && !STRIPE_KEY) return res.status(400).json({ error: 'Card payment is not available right now. Please choose another payment method.' });
    if (method === 'transfer' && !transferOn()) return res.status(400).json({ error: 'Bank transfer is not available right now. Please choose another payment method.' });
    if (!Array.isArray(items) || !items.length) return res.status(400).json({ error: 'Your cart is empty.' });
    const c = { name: clean(customer?.name, 80), phone: clean(customer?.phone, 20), email: clean(customer?.email, 100), city: clean(customer?.city, 60), address: clean(customer?.address, 300), notes: clean(customer?.notes, 300) };
    if (!c.name || !c.phone || !c.city || !c.address) return res.status(400).json({ error: 'Please fill name, phone, city and address.' });
    if (!/^[0-9+\-\s]{10,15}$/.test(c.phone)) return res.status(400).json({ error: 'Please enter a valid phone number.' });

    const products = read(files.products), lines = [];
    let subtotal = 0;
    for (const it of items.slice(0, 30)) {
      const p = products.find((x) => x.id === it.id && x.active !== false);
      const qty = Math.min(Math.max(parseInt(it.qty, 10) || 1, 1), 20);
      if (!p) return res.status(400).json({ error: 'A product in your cart is no longer available.' });
      lines.push({ id: p.id, name: p.name, color: clean(it.color, 30), qty, price: p.price });
      subtotal += p.price * qty;
    }
    let discount = 0, usedCode = '';
    const promos = read(files.promos);
    if (promoCode) {
      const p = promos.find((x) => x.active !== false && x.code === String(promoCode).trim());
      if (!p) return res.status(400).json({ error: 'The promo code is not valid any more. Please remove it and try again.' });
      discount = Math.round(subtotal * p.percent / 100); usedCode = p.code;
    }
    const shipping = subtotal >= FREE_SHIPPING_OVER ? 0 : SHIPPING_FEE;
    const orders = read(files.orders), user = authUser(req);
    const id = 'NYB-' + String(1001 + orders.length);
    const order = {
      id, createdAt: new Date().toISOString(), status: 'new', payment: { cod: 'Cash on delivery', card: 'Card (online)', transfer: 'Bank transfer / wallet' }[method],
      paymentMethod: method, paymentStatus: { cod: 'pay on delivery', card: 'pending', transfer: 'awaiting payment' }[method],
      userId: user ? user.id : null, customer: c, items: lines, subtotal, promoCode: usedCode, discount, shipping, total: subtotal - discount + shipping,
    };
    let checkoutUrl = '';
    if (method === 'card') {
      const base = SITE_URL || `${req.protocol}://${req.get('host')}`;
      const session = await stripeSession(order, base);
      order.stripeSessionId = session.id; checkoutUrl = session.url;
    }
    if (usedCode) { const p = promos.find((x) => x.code === usedCode); p.used = (p.used || 0) + 1; write(files.promos, promos); }
    orders.push(order); write(files.orders, orders);

    const text = `New order ${id} (${order.payment}, ${order.paymentStatus})\n\n${lines.map((l) => `${l.qty} x ${l.name} (${l.color}) - Rs ${l.price * l.qty}`).join('\n')}\n\n${discount ? `Promo ${usedCode}: -Rs ${discount}\n` : ''}Total: Rs ${order.total}\n\nName: ${c.name}\nPhone: ${c.phone}\nCity: ${c.city}\nAddress: ${c.address}\nNotes: ${c.notes}`;
    notify('NAYABÉ - New order ' + id, text);
    const waText = encodeURIComponent(`Hello NAYABÉ, I placed order ${id}. Total Rs ${order.total}. Name: ${c.name}.`);
    res.json({ ok: true, orderId: id, total: order.total, discount, method, checkoutUrl, whatsappUrl: `https://wa.me/${WHATSAPP}?text=${waText}` });
  } catch (e) {
    console.log('Order error:', e.message);
    res.status(502).json({ error: e.message || 'Something went wrong. Please try again.' });
  }
});

// confirm a card payment after the customer returns from the payment page
app.get('/api/orders/:id/verify', limit(30), async (req, res) => {
  const orders = read(files.orders), o = orders.find((x) => x.id === req.params.id);
  const sid = String(req.query.session_id || '');
  if (!o || o.paymentMethod !== 'card' || !sid || o.stripeSessionId !== sid) return res.status(404).json({ error: 'Order not found.' });
  if (o.paymentStatus !== 'paid') {
    try {
      const r = await fetch(`${STRIPE_BASE}/v1/checkout/sessions/${encodeURIComponent(sid)}`, { headers: { Authorization: 'Bearer ' + STRIPE_KEY } });
      const d = await r.json();
      if (r.ok && d.payment_status === 'paid' && d.amount_total === o.total * 100 && d.metadata && d.metadata.orderId === o.id) {
        o.paymentStatus = 'paid'; o.paidAt = new Date().toISOString(); write(files.orders, orders);
        notify('NAYABÉ - Card payment received ' + o.id, `Order ${o.id} was paid by card. Total Rs ${o.total}.`);
      }
    } catch (e) { return res.status(502).json({ error: 'We could not confirm your payment yet. Please contact us on WhatsApp with your order number.' }); }
  }
  res.json({ orderId: o.id, total: o.total, discount: o.discount, paid: o.paymentStatus === 'paid', whatsappUrl: `https://wa.me/${WHATSAPP}?text=${encodeURIComponent(`Hello NAYABÉ, I paid for order ${o.id} by card.`)}` });
});

app.post('/api/contact', limit(5), (req, res) => {
  const m = { id: Date.now(), createdAt: new Date().toISOString(), name: clean(req.body?.name, 80), email: clean(req.body?.email, 100), message: clean(req.body?.message, 1500), read: false };
  if (!m.name || !m.email || !m.message) return res.status(400).json({ error: 'Please fill all fields.' });
  const all = read(files.messages); all.push(m); write(files.messages, all);
  notify('NAYABÉ - New message from ' + m.name, `${m.message}\n\nFrom: ${m.name} <${m.email}>`);
  res.json({ ok: true });
});

// ---------- admin API ----------
const admin = (req, res, next) => (req.get('x-admin-key') === ADMIN_KEY ? next() : res.status(401).json({ error: 'Wrong admin key' }));
app.get('/api/admin/orders', admin, (req, res) => res.json(read(files.orders).reverse()));
app.patch('/api/admin/orders/:id', admin, (req, res) => {
  const orders = read(files.orders), o = orders.find((x) => x.id === req.params.id);
  if (!o) return res.status(404).json({ error: 'Order not found' });
  if (['new', 'confirmed', 'shipped', 'delivered', 'cancelled'].includes(req.body?.status)) o.status = req.body.status;
  if (['pay on delivery', 'awaiting payment', 'pending', 'paid'].includes(req.body?.paymentStatus)) o.paymentStatus = req.body.paymentStatus;
  write(files.orders, orders); res.json(o);
});
app.get('/api/admin/messages', admin, (req, res) => res.json(read(files.messages).reverse()));
app.get('/api/admin/customers', admin, (req, res) => res.json(read(files.users).map(publicUser).reverse()));
app.get('/api/admin/products', admin, (req, res) => res.json(read(files.products)));
app.patch('/api/admin/products/:id', admin, (req, res) => {
  const all = read(files.products), p = all.find((x) => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: 'Product not found' });
  if (req.body.price != null) p.price = Math.max(0, parseInt(req.body.price, 10) || p.price);
  if (typeof req.body.active === 'boolean') p.active = req.body.active;
  if (typeof req.body.isNew === 'boolean') p.isNew = req.body.isNew;
  if (Array.isArray(req.body.images)) p.images = req.body.images.map((s) => clean(s, 200)).slice(0, 6);
  write(files.products, all); res.json(p);
});
app.get('/api/admin/payment', admin, (req, res) => res.json({ ...payInfo(), cardEnabled: !!STRIPE_KEY }));
app.put('/api/admin/payment', admin, (req, res) => {
  const cur = payInfo();
  for (const [k, max] of [['accountTitle', 80], ['bankName', 80], ['iban', 60], ['jazzcash', 30], ['easypaisa', 30], ['note', 300]]) if (req.body?.[k] != null) cur[k] = clean(req.body[k], max);
  write(files.payment, cur); res.json({ ...cur, cardEnabled: !!STRIPE_KEY });
});
app.get('/api/admin/promos', admin, (req, res) => res.json(read(files.promos)));
app.post('/api/admin/promos', admin, (req, res) => {
  const code = clean(req.body?.code, 30), percent = Math.min(90, Math.max(1, parseInt(req.body?.percent, 10) || 0));
  if (!code || !percent) return res.status(400).json({ error: 'Enter a code and a percent (1-90).' });
  const all = read(files.promos);
  if (all.some((p) => p.code === code)) return res.status(400).json({ error: 'This code already exists.' });
  all.push({ code, percent, active: true, used: 0 }); write(files.promos, all); res.json(all);
});
app.patch('/api/admin/promos/:code', admin, (req, res) => {
  const all = read(files.promos), p = all.find((x) => x.code === req.params.code);
  if (!p) return res.status(404).json({ error: 'Promo not found' });
  if (typeof req.body.active === 'boolean') p.active = req.body.active;
  if (req.body.percent != null) p.percent = Math.min(90, Math.max(1, parseInt(req.body.percent, 10) || p.percent));
  write(files.promos, all); res.json(p);
});

app.use((req, res) => res.status(404).sendFile(path.join(__dirname, 'public', '404.html')));
app.listen(PORT, () => console.log(`NAYABÉ running on http://localhost:${PORT}`));
