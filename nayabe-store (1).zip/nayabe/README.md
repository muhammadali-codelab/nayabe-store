# NAYABÉ - Wallet Store (Frontend + Backend)

Node.js + Express backend, plain HTML/CSS/JS frontend. Koi database install karne ki zaroorat nahi
(orders aur messages `data/` folder ki JSON files mein save hote hain).

## Chalane ka tareeqa (computer par)
1. Node.js install karein: https://nodejs.org (LTS version)
2. Is folder mein terminal kholein aur chalayein:
   ```
   npm install
   ADMIN_KEY=apna-password npm start        (Windows PowerShell: $env:ADMIN_KEY="apna-password"; npm start)
   ```
3. Browser mein kholein: http://localhost:3000
4. Admin panel: http://localhost:3000/admin.html (apna ADMIN_KEY dalein)

## Live karna aur payments
Poori guide `DEPLOY.md` mein hai: link kaise banega (GitHub + Render), domain, orders ka data, aur card / bank transfer payments.
Checkout par 3 payment options: Cash on delivery (hamesha), Bank transfer / JazzCash / Easypaisa (Admin > Payments mein details dalne par), Card (gateway key set karne par).

## Naya look (v3)
- Premium brand colours (dark espresso, ivory aur gold), professional NAYABÉ logo (monogram + wordmark), aur home par full-size banner (`public/images/banner-art.webp`).
- Sab se upar scrolling bar: free delivery 3000 se upar aur promo code. Text `public/js/app.js` mein `TICK` ke andar badal sakte hain.
- Home par "Shop by style" (Bifold, Long wallet, Clasp wallet wagaira).

## Naya kya hai (v2)
- **Customer login / register** (`/account.html`): customers apna account bana sakte hain, delivery address save kar sakte hain, aur apne orders dekh sakte hain. Guest checkout bhi chalta hai.
- **Promo code**: cart mein promo code likh kar Apply karein. Abhi code `30012008` par 10% discount hai. Admin panel > **Promo codes** mein naya code add karein, percent badlein, ya band karein.
- **New arrivals** (`/new-arrivals.html`) aur home par New arrivals section. Kaunsa product "new" hai wo Admin > Products mein **New** tick se chunein.
- Header mein search, login icon aur cart (bag) icon. Har product card par "Add to cart" button.
- Naye pages: FAQ (`/faq.html`), Shipping & returns (`/shipping.html`).
- Admin mein **Customers** tab (registered customers ki list).

## Pages
- `/` Home  - `/shop.html` Shop (men/women filter)  - `/product.html?id=...` Product
- `/cart.html` Cart  - `/checkout.html` Checkout (cash on delivery)  - `/order-success.html`
- `/new-arrivals.html`  - `/account.html`  - `/faq.html`  - `/shipping.html`
- `/about.html`  - `/contact.html`  - `/privacy.html`  - `/admin.html`

## Pictures (ab lag chuki hain)
50 products ki 150 pictures `public/images/` mein hain aur `data/products.json` mein jur chuki hain. Naye products ya naye pictures ke liye neeche wale steps follow karein.

## Pictures badalna / naye lagana
1. Pictures `public/images/` folder mein rakhein (jaise `slim-bifold-1.jpg`).
2. Admin panel > Products mein har product ke samne path likhein: `/images/slim-bifold-1.jpg`
   (ya `data/products.json` mein `"images": ["/images/slim-bifold-1.jpg"]` likh dein).

## Products badalna / naye products
`data/products.json` mein edit karein (name, price, colors, description). NOTE: prices abhi sample hain, apni asli prices zaroor likhein. Naya product = naya block copy karein.

## Email notification (optional)
Naya order/message aane par officialnayabe@gmail.com par email ke liye Gmail "App Password" bana kar
`SMTP_USER` aur `SMTP_PASS` environment variables set karein (`.env.example` dekhein).

## Website online (live) karna
Backend chalane ke liye Node hosting chahiye: Render.com, Railway.app, ya VPS. Upload karein, start command `npm start`,
environment variable `ADMIN_KEY` zaroor set karein. Domain (nayabe.com wagaira) hosting se connect kar sakte hain.
Note: free hosting par `data/` folder kabhi reset ho sakta hai, isliye paid plan ya persistent disk lein.
